﻿using System;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace PasswordBruteForce.Models
{
    public class BruteForce
    {
        private static readonly char[] Characters = "abcdefghijklmnopqrstuvwxyz1234567890".ToCharArray();
        private const int MaxThreads = 4;

        public Task<string> DecryptPasswordAsync(string encryptedPassword)
        {
            return Task.Run(() => DecryptPassword(encryptedPassword));
        }

        private string DecryptPassword(string encryptedPassword)
        {
            string result = null;
            ParallelOptions parallelOptions = new ParallelOptions { MaxDegreeOfParallelism = MaxThreads };
            Parallel.ForEach(Characters, parallelOptions, (character, state) =>
            {
                if (BruteForceRecursive(character.ToString(), encryptedPassword, ref result))
                {
                    state.Stop();
                }
            });
            return result;
        }

        private bool BruteForceRecursive(string attempt, string encryptedPassword, ref string result)
        {
            if (PasswordEncryptor.EncryptPassword(attempt) == encryptedPassword)
            {
                result = attempt;
                return true;
            }

            if (attempt.Length >= 5) // Limit the password length for demo purposes
                return false;

            foreach (char character in Characters)
            {
                if (BruteForceRecursive(attempt + character, encryptedPassword, ref result))
                    return true;
            }

            return false;
        }
    }
}
